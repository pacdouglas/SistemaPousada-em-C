Title: Menu using arrow keys (without blinking cursor)
Description: This is a very detailed code on how to make your menu that uses the arrow keys, and there is very usefull functions and tricks in this code, like gotoxy and how to make an array of 'pointer to function' and how to make a function return a pointer to array, and lots of stuff
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=11055&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
